const Discord = require('discord.js')
const cc = ["940246394281795595", "940246394281795595"]
module.exports = {
    config: {
        name: "eval",
        description: "ev",
        usage: "ev",
        example: "ev",
        aliases: ['evalll']
    },
    run: async (bot, message, args) => {
      if(message.author.id == "9402463942817955950" || message.author.id == "940246394281795595") {
        
        let guild = message.guild
            const prefix = "ac-"
            const ea = args.join(` `)
            if (!ea) return message.channel.send("CREATEd BY @_rudra.exe ")
            try {
                
                const done = eval(ea)
                message.channel.send("Uh, wait").then(m => {
                    const en = new Discord.MessageEmbed()
                        .addField("Input", ea)
                        .addField("Output", done)
                    m.edit(en)
                    setTimeout(function () {
                        m.delete()
                    }, 20000)
                })
            } catch (e) {
                const en = new Discord.MessageEmbed()
                    .addField("Input", ea)
                    .addField("Output", e)
                message.channel.send(en)
            }
      }
    },
}